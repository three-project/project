module.exports = {
    devServer: {
        open: true,
        proxy: {
            '/api': {
                target: 'https://mall.cxmmao.com',//目标地址
                changeOrigin: true,
                secure: false,
                pathRewrite: {
                    '^/api': ''
                }
            }
        }
    }
}