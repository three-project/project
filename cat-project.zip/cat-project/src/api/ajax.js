import axios from 'axios'
const ajax = axios.create({
    baseURL: '/api/api-mall'
})

// 添加请求拦截器
/* axios.interceptors.request.use(
    config => {
        //获取请求头
        let token = store.token
        if (token) {
            // 有token传入 header
            config.headers.token = token
        }
        return config
    }
) */
export default ajax