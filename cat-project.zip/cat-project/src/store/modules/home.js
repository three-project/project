import { reqgetGoodsList, reqgetGoodsInfoList } from '@/api'
const state = {
    goodsList: [],//存储商品列表的数组
    goodsIdList: [],//存储商品基本信息的数组
}
const mutations = {
    RECEIVE_GOODS_List(state, goodsList) {
        state.goodsList = goodsList
    },
    RECEIVE_GOODS_ID_LIST(state, goodsIdList) {
        state.goodsIdList = goodsIdList
    }
}
const actions = {
    // 调用商品列表的接口
    async getGoodsList({ commit }) {
        const result = await reqgetGoodsList()

        commit('RECEIVE_GOODS_List', result.data)

        console.log(result)
    },
    // 调用商品基本信息的数组
    async reqgetGoodsInfoList({ commit }) {
        const result = await reqgetGoodsInfoList()
        commit('RECEIVE_GOODS_ID_LIST', result.data)
    }
}
const getters = {}
export default {
    state,
    mutations,
    actions,
    getters
}