// 包含了多个转态数据的对象
export default {

}