<template>
  <div>商品详情页面</div>
</template>
<script>
export default {
  name: "Detail",
};
</script>
<style scoped>
</style>