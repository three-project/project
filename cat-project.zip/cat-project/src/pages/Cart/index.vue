<template>
    <div>购物车页面</div>
</template>
<script>
export default {
    name:'Cart'
}
</script>
<style scoped>

</style>