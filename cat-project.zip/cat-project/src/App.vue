<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style scoped>
#app {
  display: flex;
  justify-content: center;
  min-width: 1200px;
  color: #2c3e50;
  margin: 0;
  padding: 0;
  background: #f6f6f6;
}
</style>
